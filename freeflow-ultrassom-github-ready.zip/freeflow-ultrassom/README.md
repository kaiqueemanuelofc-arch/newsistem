
FreeFlow · Ultrassom (Frontend pronto)
- Edite: src/script.js constants WEBHOOK_INGEST_URL and PUBLIC_REPORT_URL
- Push to GitHub and link to Vercel (public/ as static folder)
